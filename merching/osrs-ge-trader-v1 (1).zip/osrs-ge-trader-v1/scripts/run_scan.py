from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from ge_trader.app import run_scan  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--db", required=False)
    args = parser.parse_args()

    result = run_scan(args.config, args.db)

    print("\nSelected candidates")
    print("=" * 80)
    for c in result["selected"]:
        print(
            f"{c.item_name:28} "
            f"entry={c.entry_price:>8} "
            f"exit={c.exit_price:>8} "
            f"edge={c.edge_gp:>6} "
            f"roi={c.roi_pct:>5.2f}% "
            f"qty={c.allocated_qty:>6} "
            f"gp={c.allocated_gp:>9} "
            f"score={c.score:>10.1f}"
        )

    if result["unresolved"]:
        print("\nUnresolved whitelist names")
        print("=" * 80)
        for name in result["unresolved"]:
            print(f"- {name}")

    if result["excluded"]:
        print("\nExcluded raw names")
        print("=" * 80)
        for name in result["excluded"]:
            print(f"- {name}")


if __name__ == "__main__":
    main()
