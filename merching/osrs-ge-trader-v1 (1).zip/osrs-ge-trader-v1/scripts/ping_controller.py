from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from ge_trader.execution.arduino_hid import ArduinoHID  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", required=True)
    parser.add_argument("--baudrate", type=int, default=115200)
    args = parser.parse_args()

    with ArduinoHID(port=args.port, baudrate=args.baudrate) as hid:
        hid.ping()
        print("Controller ping succeeded.")


if __name__ == "__main__":
    main()
