from __future__ import annotations

import argparse

from ge_trader.state.db import connect, init_db


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True)
    args = parser.parse_args()

    conn = connect(args.db)
    init_db(conn)
    conn.close()
    print(f"Initialized database at {args.db}")


if __name__ == "__main__":
    main()
