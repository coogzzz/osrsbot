from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from ge_trader.config import load_yaml  # noqa: E402
from ge_trader.scheduling.daily import generate_daily_run_times  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--seed", type=int, required=False)
    args = parser.parse_args()

    cfg = load_yaml(args.config)
    scfg = cfg["scheduling"]

    run_times = generate_daily_run_times(
        target_date=date.today(),
        start_hhmm=scfg["active_window_start"],
        end_hhmm=scfg["active_window_end"],
        min_runs=int(scfg["min_runs_per_day"]),
        max_runs=int(scfg["max_runs_per_day"]),
        min_spacing_minutes=int(scfg["min_spacing_minutes"]),
        seed=args.seed,
    )

    print("Today's randomized run times")
    print("=" * 80)
    for ts in run_times:
        print(ts.strftime("%Y-%m-%d %H:%M"))


if __name__ == "__main__":
    main()
