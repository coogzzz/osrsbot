Foundation notes

- The attached `flip-dashboard.html` is a useful idea source for:
  - using `/mapping`, `/latest`, `/24h`
  - post-tax edge math
  - stale quote checks
  - 4h fill estimation from 24h volume
  - row-level trade diagnostics
- This scaffold keeps those ideas but moves them into Python and tightens them with `/1h` confirmation, SQLite logging, and bankroll-aware allocation.
