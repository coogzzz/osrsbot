# OSRS GE Trader v1

A thin, standalone Python project for **whitelist-driven Grand Exchange opportunity scanning and trade planning**.

This project is intentionally scoped to:

- OSRS Wiki real-time price ingestion
- whitelist normalization against the official item mapping
- conservative post-tax trade scoring
- bankroll-aware allocation for a 6M bankroll
- SQLite state and decision logging
- randomized daily scan windows
- Arduino Leonardo serial HID sender foundation

It does **not** include direct in-game automation logic. The execution boundary is kept behind a thin interface on purpose.

## Current assumptions

- Bankroll: 6,000,000 gp
- Activity window: 08:00 to 22:00 local time
- Daily scan count: random 5 to 8
- Max concurrent buys: 4
- Max concurrent sells: 4
- Focus: maximize expected daily gp on reasonably liquid whitelist items
- Platform: Windows + RuneLite + 1920x1080 + fixed layout

## Why the scanner uses the OSRS Wiki API this way

The official OSRS Wiki real-time prices API exposes bulk `/mapping`, `/latest`, `/5m`, `/1h`, and `/timeseries` endpoints. It asks callers to set a descriptive `User-Agent`, explicitly warns against looping the `id` parameter over all items, and notes there may be downtime or imperfect data. The scanner therefore uses:

- `/mapping` for item metadata and buy limits
- `/24h` for broad discovery
- `/latest` for freshness and divergence checks
- `/1h` for shortlist confirmation

This is the intended pattern for a lightweight trading tool, and it is safer than overfitting to single last-trade prints.

## Quick start

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

python scripts/init_db.py --db data/ge_trader.db
python scripts/run_scan.py --config config/settings.example.yml --db data/ge_trader.db
python scripts/generate_schedule.py --config config/settings.example.yml
```

## What is implemented

- OSRS Wiki API client with required custom `User-Agent`
- whitelist normalization against `/mapping`
- feature building with:
  - 24h and 1h pricing
  - recent divergence checks
  - staleness checks
  - conservative entry/exit prices
  - post-tax edge
  - fill estimate
- ranking and bankroll allocation
- SQLite decision logging
- Arduino HID serial sender using your packet contract
- daily randomized schedule generator

## What is intentionally deferred

- direct screen interaction
- OCR / computer vision
- in-game state detection
- automatic buy/sell clicking
- offer reconciliation from the game client

## Project layout

```text
config/
  settings.example.yml
  whitelist.yml

src/ge_trader/
  config.py
  models.py
  app.py
  data/
  strategy/
  risk/
  state/
  execution/
  scheduling/

scripts/
  init_db.py
  run_scan.py
  generate_schedule.py
  ping_controller.py
```
