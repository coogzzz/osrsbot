from ge_trader.execution.protocol import CMD_PING, checksum, pack_packet


def test_packet_length():
    packet = pack_packet(CMD_PING, 0, 0, 0)
    assert len(packet) == 8


def test_checksum():
    payload = bytes([0x05, 0, 0, 0, 0, 0, 0])
    assert checksum(payload) == 0x05
