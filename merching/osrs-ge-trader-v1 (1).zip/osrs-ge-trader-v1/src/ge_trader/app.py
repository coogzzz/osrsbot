from __future__ import annotations

from datetime import datetime, timezone

from ge_trader.config import load_yaml
from ge_trader.data.features import build_candidate_features
from ge_trader.data.whitelist_loader import resolve_whitelist
from ge_trader.data.wiki_client import WikiClient
from ge_trader.risk.allocator import allocate_candidates
from ge_trader.state.db import complete_cycle_run, connect, init_db, insert_candidates, insert_cycle_run
from ge_trader.strategy.ranker import rank_candidates


def run_scan(config_path: str, db_path: str | None = None) -> dict:
    cfg = load_yaml(config_path)

    db_file = db_path or cfg["database"]["path"]
    conn = connect(db_file)
    init_db(conn)

    started_at = datetime.now(timezone.utc).isoformat()
    cycle_run_id = insert_cycle_run(conn, started_at=started_at, status="running")

    try:
        client = WikiClient(
            base_url=cfg["data"]["base_url"],
            user_agent=cfg["project"]["user_agent"],
            timeout_seconds=int(cfg["data"]["request_timeout_seconds"]),
            cache_dir=cfg["data"]["cache_dir"],
        )

        mapping = client.get_mapping()
        whitelist = resolve_whitelist(mapping, cfg["data"]["whitelist_file"])

        latest = client.get_latest()
        daily = client.get_24h()
        hourly = client.get_1h()

        features = build_candidate_features(
            mapping_items=whitelist.resolved,
            latest=latest,
            hourly=hourly,
            daily=daily,
            slippage_buffer_gp=int(cfg["strategy"]["slippage_buffer_gp"]),
        )
        accepted, rejected = rank_candidates(features, cfg["strategy"])
        selected = allocate_candidates(accepted, cfg["bankroll"])

        to_log = list(selected) + rejected
        insert_candidates(conn, cycle_run_id, to_log)

        completed_at = datetime.now(timezone.utc).isoformat()
        notes = f"resolved={len(whitelist.resolved)} unresolved={len(whitelist.unresolved)} selected={len(selected)}"
        complete_cycle_run(conn, cycle_run_id, completed_at=completed_at, status="completed", notes=notes)

        return {
            "cycle_run_id": cycle_run_id,
            "selected": selected,
            "rejected": rejected,
            "unresolved": whitelist.unresolved,
            "excluded": whitelist.excluded,
        }
    except Exception as exc:
        completed_at = datetime.now(timezone.utc).isoformat()
        complete_cycle_run(conn, cycle_run_id, completed_at=completed_at, status="failed", notes=str(exc))
        raise
    finally:
        conn.close()
