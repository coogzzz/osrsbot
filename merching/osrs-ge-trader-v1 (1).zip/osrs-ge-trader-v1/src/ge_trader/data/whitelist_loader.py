from __future__ import annotations

from dataclasses import dataclass

from ge_trader.config import load_yaml
from ge_trader.models import MappingItem


@dataclass(slots=True)
class WhitelistResolution:
    resolved: list[MappingItem]
    unresolved: list[str]
    excluded: list[str]


def resolve_whitelist(mapping_items: list[MappingItem], whitelist_path: str) -> WhitelistResolution:
    raw = load_yaml(whitelist_path)
    raw_items = raw.get("raw_items", [])
    excluded = list(raw.get("excluded_raw_items", []))

    mapping_by_lower = {item.name.lower(): item for item in mapping_items}

    resolved: list[MappingItem] = []
    unresolved: list[str] = []

    seen_ids: set[int] = set()
    for name in raw_items:
        match = mapping_by_lower.get(str(name).strip().lower())
        if match is None:
            unresolved.append(str(name))
            continue
        if match.id in seen_ids:
            continue
        resolved.append(match)
        seen_ids.add(match.id)

    return WhitelistResolution(resolved=resolved, unresolved=unresolved, excluded=excluded)
