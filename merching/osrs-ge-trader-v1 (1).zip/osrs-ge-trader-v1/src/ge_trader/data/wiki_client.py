from __future__ import annotations

from pathlib import Path
from typing import Any

import hashlib
import json
import time

import requests

from ge_trader.models import MappingItem, PriceSnapshot


class WikiClient:
    def __init__(
        self,
        base_url: str,
        user_agent: str,
        timeout_seconds: int = 20,
        cache_dir: str | Path | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": user_agent})
        self.cache_dir = Path(cache_dir) if cache_dir else None
        if self.cache_dir:
            self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _cache_key(self, path: str, params: dict[str, Any] | None) -> str:
        blob = json.dumps({"path": path, "params": params or {}}, sort_keys=True).encode("utf-8")
        return hashlib.sha256(blob).hexdigest()

    def _cache_get(self, key: str, max_age_seconds: int) -> Any | None:
        if not self.cache_dir:
            return None
        target = self.cache_dir / f"{key}.json"
        if not target.exists():
            return None
        age = time.time() - target.stat().st_mtime
        if age > max_age_seconds:
            return None
        with target.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def _cache_put(self, key: str, payload: Any) -> None:
        if not self.cache_dir:
            return
        target = self.cache_dir / f"{key}.json"
        with target.open("w", encoding="utf-8") as handle:
            json.dump(payload, handle)

    def _get(self, path: str, params: dict[str, Any] | None = None, cache_ttl_seconds: int = 0) -> Any:
        key = self._cache_key(path, params)
        if cache_ttl_seconds > 0:
            cached = self._cache_get(key, cache_ttl_seconds)
            if cached is not None:
                return cached

        response = self.session.get(
            f"{self.base_url}{path}",
            params=params,
            timeout=self.timeout_seconds,
        )
        response.raise_for_status()
        payload = response.json()

        if cache_ttl_seconds > 0:
            self._cache_put(key, payload)
        return payload

    def get_mapping(self) -> list[MappingItem]:
        payload = self._get("/mapping", cache_ttl_seconds=12 * 60 * 60)
        items: list[MappingItem] = []
        for row in payload:
            items.append(
                MappingItem(
                    id=int(row["id"]),
                    name=str(row["name"]),
                    members=bool(row["members"]),
                    limit=int(row["limit"]) if row.get("limit") is not None else 0,
                    highalch=int(row["highalch"]) if row.get("highalch") is not None else None,
                    lowalch=int(row["lowalch"]) if row.get("lowalch") is not None else None,
                    value=int(row["value"]) if row.get("value") is not None else None,
                    icon=row.get("icon"),
                )
            )
        return items

    def get_latest(self) -> dict[int, PriceSnapshot]:
        payload = self._get("/latest", cache_ttl_seconds=60)
        return self._normalize_snapshots(payload.get("data", {}))

    def get_24h(self) -> dict[int, PriceSnapshot]:
        payload = self._get("/24h", cache_ttl_seconds=60)
        return self._normalize_snapshots(payload.get("data", {}))

    def get_1h(self) -> dict[int, PriceSnapshot]:
        payload = self._get("/1h", cache_ttl_seconds=60)
        return self._normalize_snapshots(payload.get("data", {}))

    def _normalize_snapshots(self, raw: dict[str, Any]) -> dict[int, PriceSnapshot]:
        out: dict[int, PriceSnapshot] = {}
        for item_id, row in raw.items():
            out[int(item_id)] = PriceSnapshot(
                high=row.get("high"),
                low=row.get("low"),
                high_time=row.get("highTime"),
                low_time=row.get("lowTime"),
                avg_high_price=row.get("avgHighPrice"),
                avg_low_price=row.get("avgLowPrice"),
                high_price_volume=row.get("highPriceVolume"),
                low_price_volume=row.get("lowPriceVolume"),
                timestamp=row.get("timestamp"),
            )
        return out
