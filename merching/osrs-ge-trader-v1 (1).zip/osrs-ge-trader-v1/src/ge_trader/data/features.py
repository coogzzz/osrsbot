from __future__ import annotations

import math
import time
from typing import Iterable

from ge_trader.models import CandidateFeatures, MappingItem, PriceSnapshot
from ge_trader.strategy.tax import ge_tax


def _safe_int(value: int | None) -> int:
    return int(value) if value is not None else 0


def build_candidate_features(
    mapping_items: Iterable[MappingItem],
    latest: dict[int, PriceSnapshot],
    hourly: dict[int, PriceSnapshot],
    daily: dict[int, PriceSnapshot],
    slippage_buffer_gp: int,
) -> list[CandidateFeatures]:
    now = int(time.time())
    out: list[CandidateFeatures] = []

    for item in mapping_items:
        p24 = daily.get(item.id)
        if not p24 or not p24.avg_low_price or not p24.avg_high_price:
            continue

        plast = latest.get(item.id, PriceSnapshot())
        p1h = hourly.get(item.id, PriceSnapshot())

        avg24h_buy = _safe_int(p24.avg_low_price)
        avg24h_sell = _safe_int(p24.avg_high_price)
        avg1h_buy = _safe_int(p1h.avg_low_price) or None
        avg1h_sell = _safe_int(p1h.avg_high_price) or None
        latest_buy = _safe_int(plast.low) or None
        latest_sell = _safe_int(plast.high) or None

        if avg24h_buy <= 0 or avg24h_sell <= 0 or avg24h_sell <= avg24h_buy:
            continue

        # Conservative, recent-aware references.
        entry_price = max(avg24h_buy, avg1h_buy or avg24h_buy)
        exit_price = min(avg24h_sell, avg1h_sell or avg24h_sell)

        if exit_price <= entry_price:
            continue

        tax_per_item = ge_tax(exit_price)
        edge_gp = exit_price - entry_price - tax_per_item - slippage_buffer_gp
        if edge_gp <= 0:
            continue

        roi_pct = (edge_gp / entry_price) * 100.0

        v24_buy = _safe_int(p24.low_price_volume)
        v24_sell = _safe_int(p24.high_price_volume)
        v1h_buy = _safe_int(p1h.low_price_volume)
        v1h_sell = _safe_int(p1h.high_price_volume)

        thin_24h = min(v24_buy, v24_sell)
        conservative_fill_estimate = min(item.limit or 0, math.floor(thin_24h / 6)) if item.limit else math.floor(thin_24h / 6)
        if conservative_fill_estimate <= 0:
            continue

        last_trade = max(_safe_int(plast.high_time), _safe_int(plast.low_time))
        stale_seconds = max(0, now - last_trade) if last_trade else 999999999

        divs = []
        if latest_buy:
            divs.append(abs(latest_buy - entry_price) / entry_price * 100.0)
        if latest_sell:
            divs.append(abs(latest_sell - exit_price) / exit_price * 100.0)
        latest_divergence_pct = max(divs) if divs else 100.0

        out.append(
            CandidateFeatures(
                item_id=item.id,
                item_name=item.name,
                members=item.members,
                buy_limit=item.limit or 0,
                avg24h_buy=avg24h_buy,
                avg24h_sell=avg24h_sell,
                avg1h_buy=avg1h_buy,
                avg1h_sell=avg1h_sell,
                latest_buy=latest_buy,
                latest_sell=latest_sell,
                volume24h_buy=v24_buy,
                volume24h_sell=v24_sell,
                volume1h_buy=v1h_buy,
                volume1h_sell=v1h_sell,
                stale_seconds=stale_seconds,
                latest_divergence_pct=latest_divergence_pct,
                entry_price=entry_price,
                exit_price=exit_price,
                tax_per_item=tax_per_item,
                edge_gp=edge_gp,
                roi_pct=roi_pct,
                conservative_fill_estimate=conservative_fill_estimate,
            )
        )

    return out
