from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass(slots=True)
class MappingItem:
    id: int
    name: str
    members: bool
    limit: Optional[int]
    highalch: Optional[int]
    lowalch: Optional[int]
    value: Optional[int] = None
    icon: Optional[str] = None


@dataclass(slots=True)
class PriceSnapshot:
    high: Optional[int] = None
    low: Optional[int] = None
    high_time: Optional[int] = None
    low_time: Optional[int] = None
    avg_high_price: Optional[int] = None
    avg_low_price: Optional[int] = None
    high_price_volume: Optional[int] = None
    low_price_volume: Optional[int] = None
    timestamp: Optional[int] = None


@dataclass(slots=True)
class CandidateFeatures:
    item_id: int
    item_name: str
    members: bool
    buy_limit: int
    avg24h_buy: int
    avg24h_sell: int
    avg1h_buy: Optional[int]
    avg1h_sell: Optional[int]
    latest_buy: Optional[int]
    latest_sell: Optional[int]
    volume24h_buy: int
    volume24h_sell: int
    volume1h_buy: int
    volume1h_sell: int
    stale_seconds: int
    latest_divergence_pct: float
    entry_price: int
    exit_price: int
    tax_per_item: int
    edge_gp: int
    roi_pct: float
    conservative_fill_estimate: int
    score: float = 0.0
    confidence: float = 0.0
    allocated_qty: int = 0
    allocated_gp: int = 0
    rejection_reason: Optional[str] = None
    notes: list[str] = field(default_factory=list)
