from __future__ import annotations

from ge_trader.models import CandidateFeatures
from ge_trader.strategy.rules import apply_filters, score_candidate


def rank_candidates(candidates: list[CandidateFeatures], strategy_cfg: dict) -> tuple[list[CandidateFeatures], list[CandidateFeatures]]:
    accepted: list[CandidateFeatures] = []
    rejected: list[CandidateFeatures] = []

    for candidate in candidates:
        candidate = apply_filters(candidate, strategy_cfg)
        if candidate.rejection_reason:
            rejected.append(candidate)
            continue
        candidate = score_candidate(candidate, strategy_cfg)
        accepted.append(candidate)

    accepted.sort(key=lambda c: c.score, reverse=True)
    rejected.sort(key=lambda c: (c.rejection_reason or "", c.item_name))
    return accepted, rejected
