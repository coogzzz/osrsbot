from __future__ import annotations


def ge_tax(sell_price: int) -> int:
    if sell_price < 50:
        return 0
    return min((sell_price * 2) // 100, 5_000_000)
