from __future__ import annotations

from ge_trader.models import CandidateFeatures


def apply_filters(candidate: CandidateFeatures, strategy_cfg: dict) -> CandidateFeatures:
    if candidate.edge_gp < int(strategy_cfg["min_edge_gp"]):
        candidate.rejection_reason = "edge_too_small"
        return candidate

    if candidate.roi_pct < float(strategy_cfg["min_roi_pct"]):
        candidate.rejection_reason = "roi_too_small"
        return candidate

    if candidate.volume24h_buy + candidate.volume24h_sell < int(strategy_cfg["min_24h_total_volume"]):
        candidate.rejection_reason = "daily_volume_too_small"
        return candidate

    if strategy_cfg.get("require_recent_confirmation", True):
        if min(candidate.volume1h_buy, candidate.volume1h_sell) < int(strategy_cfg["min_1h_side_volume"]):
            candidate.rejection_reason = "hourly_volume_too_small"
            return candidate

    if candidate.stale_seconds > int(strategy_cfg["max_stale_seconds"]):
        candidate.rejection_reason = "stale_quotes"
        return candidate

    if candidate.latest_divergence_pct > float(strategy_cfg["max_latest_divergence_pct"]):
        candidate.rejection_reason = "latest_divergence_too_high"
        return candidate

    return candidate


def score_candidate(candidate: CandidateFeatures, strategy_cfg: dict) -> CandidateFeatures:
    confidence = 1.0

    if candidate.stale_seconds > 1800:
        confidence *= 0.85
        candidate.notes.append("staleness_penalty")

    if candidate.latest_divergence_pct > 3.0:
        confidence *= 0.85
        candidate.notes.append("divergence_penalty")

    recent_side = min(candidate.volume1h_buy, candidate.volume1h_sell)
    if recent_side < max(100, candidate.buy_limit // 10):
        confidence *= 0.90
        candidate.notes.append("recent_liquidity_penalty")

    floor = float(strategy_cfg.get("confidence_floor", 0.35))
    candidate.confidence = max(confidence, floor)
    candidate.score = candidate.edge_gp * candidate.conservative_fill_estimate * candidate.confidence
    return candidate
