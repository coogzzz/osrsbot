from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Iterable

from ge_trader.models import CandidateFeatures


SCHEMA = '''
CREATE TABLE IF NOT EXISTS cycle_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    status TEXT NOT NULL,
    notes TEXT
);

CREATE TABLE IF NOT EXISTS candidates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cycle_run_id INTEGER NOT NULL,
    item_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    edge_gp INTEGER NOT NULL,
    roi_pct REAL NOT NULL,
    score REAL NOT NULL,
    confidence REAL NOT NULL,
    entry_price INTEGER NOT NULL,
    exit_price INTEGER NOT NULL,
    allocated_qty INTEGER NOT NULL,
    allocated_gp INTEGER NOT NULL,
    stale_seconds INTEGER NOT NULL,
    latest_divergence_pct REAL NOT NULL,
    rejection_reason TEXT,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(cycle_run_id) REFERENCES cycle_runs(id)
);
'''


def connect(db_path: str | Path) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def insert_cycle_run(conn: sqlite3.Connection, started_at: str, status: str, notes: str = "") -> int:
    cur = conn.execute(
        "INSERT INTO cycle_runs (started_at, status, notes) VALUES (?, ?, ?)",
        (started_at, status, notes),
    )
    conn.commit()
    return int(cur.lastrowid)


def complete_cycle_run(conn: sqlite3.Connection, cycle_run_id: int, completed_at: str, status: str, notes: str = "") -> None:
    conn.execute(
        "UPDATE cycle_runs SET completed_at = ?, status = ?, notes = ? WHERE id = ?",
        (completed_at, status, notes, cycle_run_id),
    )
    conn.commit()


def insert_candidates(conn: sqlite3.Connection, cycle_run_id: int, candidates: Iterable[CandidateFeatures]) -> None:
    rows = [
        (
            cycle_run_id,
            c.item_id,
            c.item_name,
            c.edge_gp,
            c.roi_pct,
            c.score,
            c.confidence,
            c.entry_price,
            c.exit_price,
            c.allocated_qty,
            c.allocated_gp,
            c.stale_seconds,
            c.latest_divergence_pct,
            c.rejection_reason,
            ",".join(c.notes),
        )
        for c in candidates
    ]
    conn.executemany(
        '''
        INSERT INTO candidates (
            cycle_run_id, item_id, item_name, edge_gp, roi_pct, score, confidence,
            entry_price, exit_price, allocated_qty, allocated_gp, stale_seconds,
            latest_divergence_pct, rejection_reason, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''',
        rows,
    )
    conn.commit()
