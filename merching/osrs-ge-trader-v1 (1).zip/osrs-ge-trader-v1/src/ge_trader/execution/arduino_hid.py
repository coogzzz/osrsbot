from __future__ import annotations

import time

import serial

from ge_trader.execution.protocol import (
    ACK,
    CMD_CLICK,
    CMD_MOUSE_PRESS,
    CMD_MOUSE_RELEASE,
    CMD_MOVE_REL,
    CMD_PING,
    CMD_TYPE,
    NAK,
    READY,
    pack_packet,
)


class ArduinoHID:
    def __init__(
        self,
        port: str,
        baudrate: int = 115200,
        read_timeout_seconds: float = 1.0,
        write_timeout_seconds: float = 1.0,
        max_retries: int = 3,
    ) -> None:
        self.port = port
        self.baudrate = baudrate
        self.read_timeout_seconds = read_timeout_seconds
        self.write_timeout_seconds = write_timeout_seconds
        self.max_retries = max_retries
        self.serial: serial.Serial | None = None

    def open(self) -> None:
        self.serial = serial.Serial(
            port=self.port,
            baudrate=self.baudrate,
            timeout=self.read_timeout_seconds,
            write_timeout=self.write_timeout_seconds,
        )
        time.sleep(1.3)

    def close(self) -> None:
        if self.serial and self.serial.is_open:
            self.serial.close()

    def __enter__(self) -> "ArduinoHID":
        self.open()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _send(self, cmd: int, p1: int = 0, p2: int = 0, p3: int = 0) -> None:
        if not self.serial or not self.serial.is_open:
            raise RuntimeError("serial port is not open")

        packet = pack_packet(cmd, p1, p2, p3)

        for attempt in range(1, self.max_retries + 1):
            self.serial.reset_input_buffer()
            self.serial.write(packet)
            self.serial.flush()

            ack = self.serial.read(1)
            if not ack:
                if attempt == self.max_retries:
                    raise TimeoutError("no ACK/NAK received")
                continue

            code = ack[0]
            if code == NAK:
                if attempt == self.max_retries:
                    raise RuntimeError("controller returned NAK")
                continue
            if code != ACK:
                if attempt == self.max_retries:
                    raise RuntimeError(f"unexpected response byte: {code:#x}")
                continue

            ready = self.serial.read(1)
            if not ready:
                if attempt == self.max_retries:
                    raise TimeoutError("no READY received after ACK")
                continue
            if ready[0] != READY:
                if attempt == self.max_retries:
                    raise RuntimeError(f"unexpected READY byte: {ready[0]:#x}")
                continue
            return

        raise RuntimeError("command failed after retries")

    def ping(self) -> None:
        self._send(CMD_PING)

    def move_relative(self, dx: int, dy: int) -> None:
        self._send(CMD_MOVE_REL, p1=dx, p2=dy)

    def click(self, hold_ms: int = 30) -> None:
        self._send(CMD_CLICK, p3=hold_ms)

    def mouse_press(self, button_mask: int = 1, hold_ms: int = 0) -> None:
        self._send(CMD_MOUSE_PRESS, p1=button_mask, p3=hold_ms)

    def mouse_release(self, button_mask: int = 1) -> None:
        self._send(CMD_MOUSE_RELEASE, p1=button_mask)

    def type_byte(self, code: int) -> None:
        self._send(CMD_TYPE, p1=code)

    def type_text(self, text: str) -> None:
        for ch in text:
            self.type_byte(ord(ch))

    def press_enter(self) -> None:
        self.type_byte(176)
