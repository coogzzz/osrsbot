from __future__ import annotations

import struct

ACK = 0x06
NAK = 0x15
READY = 0x11

CMD_MOVE_REL = 0x01
CMD_CLICK = 0x02
CMD_MOUSE_PRESS = 0x03
CMD_MOUSE_RELEASE = 0x04
CMD_PING = 0x05
CMD_TYPE = 0x07


def checksum(payload7: bytes) -> int:
    if len(payload7) != 7:
        raise ValueError("checksum expects exactly 7 bytes")
    return sum(payload7) & 0xFF


def pack_packet(cmd: int, p1: int = 0, p2: int = 0, p3: int = 0) -> bytes:
    payload7 = struct.pack("<Bhhh", cmd, p1, p2, p3)
    return payload7 + bytes([checksum(payload7)])
