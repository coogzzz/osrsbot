from __future__ import annotations

import random
from datetime import date, datetime, time, timedelta


def _parse_hhmm(value: str) -> time:
    hour, minute = value.split(":")
    return time(hour=int(hour), minute=int(minute))


def generate_daily_run_times(
    target_date: date,
    start_hhmm: str,
    end_hhmm: str,
    min_runs: int,
    max_runs: int,
    min_spacing_minutes: int,
    seed: int | None = None,
) -> list[datetime]:
    rng = random.Random(seed)
    count = rng.randint(min_runs, max_runs)

    start_dt = datetime.combine(target_date, _parse_hhmm(start_hhmm))
    end_dt = datetime.combine(target_date, _parse_hhmm(end_hhmm))
    if end_dt <= start_dt:
        raise ValueError("end time must be after start time")

    total_minutes = int((end_dt - start_dt).total_seconds() // 60)
    if count <= 0:
        return []

    candidate_minutes = []
    attempts = 0
    while len(candidate_minutes) < count and attempts < 10_000:
        attempts += 1
        minute_offset = rng.randint(0, total_minutes)
        if all(abs(minute_offset - existing) >= min_spacing_minutes for existing in candidate_minutes):
            candidate_minutes.append(minute_offset)

    if len(candidate_minutes) < count:
        raise RuntimeError("could not generate a schedule with the requested spacing")

    candidate_minutes.sort()
    return [start_dt + timedelta(minutes=offset) for offset in candidate_minutes]
