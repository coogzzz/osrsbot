from __future__ import annotations

from ge_trader.models import CandidateFeatures


def allocate_candidates(candidates: list[CandidateFeatures], bankroll_cfg: dict) -> list[CandidateFeatures]:
    available_gp = int(bankroll_cfg["max_total_deployed_gp"])
    reserve_gp = int(bankroll_cfg["reserve_gp"])
    total_gp = int(bankroll_cfg["total_gp"])
    spendable_gp = min(available_gp, max(total_gp - reserve_gp, 0))
    max_per_item_gp = int(bankroll_cfg["max_per_item_gp"])
    max_buys = int(bankroll_cfg["max_concurrent_buys"])

    selected: list[CandidateFeatures] = []

    for candidate in candidates:
        if len(selected) >= max_buys:
            break
        if spendable_gp < candidate.entry_price:
            break

        per_item_cap = min(spendable_gp, max_per_item_gp)
        qty_by_cash = per_item_cap // candidate.entry_price
        qty = min(candidate.buy_limit, candidate.conservative_fill_estimate, qty_by_cash)

        if qty <= 0:
            continue

        candidate.allocated_qty = qty
        candidate.allocated_gp = qty * candidate.entry_price
        spendable_gp -= candidate.allocated_gp
        selected.append(candidate)

    return selected
